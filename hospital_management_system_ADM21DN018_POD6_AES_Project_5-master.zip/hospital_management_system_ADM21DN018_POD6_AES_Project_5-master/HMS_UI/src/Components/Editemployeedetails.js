import React, { Component } from 'react';
import './EditPage.css';

import { useEffect, useState } from 'react'
function Editemployeedetails() {
    const [users, setUser] = useState([])
    const [EmployeeID, setEmployeeId] = useState('');
    const [E_AadharID, setE_AadharId] = useState("");
    const [EmployeeName, setEmployeeName] = useState("");
    const [Gender, setGender] = useState("");
    const [DOJ, setDOJ] = useState("");
    const [Phone, setPhone] = useState("");
    const [Address, setAddress]= useState("")
    const [Designation, setDesignation] = useState("");
    const [Speciality, setSpeciality]= useState("")
     
    useEffect(() => {
    getUsers();
  }, [])

  function getUsers() {
    fetch("http://localhost:64192/api/employees").then((result) => {
      result.json().then((resp) => {
     
        setUser(resp)
        setEmployeeId(resp[0].EmployeeID)
        setE_AadharId(resp[0].E_AadharID)
        setEmployeeName(resp[0].EmployeeName)
        setDesignation(resp[0].Designation)
        setSpeciality(resp[0].Speciality)
        setGender(resp[0].Gender)
        setPhone(resp[0].Phone)
        setAddress(resp[0].Address)
        setDOJ(resp[0].DOJ)
     })
    })
  }

  function selectUser(PID)
  {
    let item=users[PID-1];
    setEmployeeId(item.EmployeeID);
    setE_AadharId(item.E_AadharID);
    setEmployeeName(item.EmployeeName);
    setDesignation(item.Designation);
    setSpeciality(item.Speciality);
    setGender(item.Gender)
    setPhone(item.Phone);
    setAddress(item.Address);
    setDOJ(item.DOJ)
  }
  
  
  function updateUser()
  {
    let item={EmployeeID,E_AadharID,EmployeeName,Designation,Speciality,Gender,Phone,Address,DOJ}
    console.warn("item",item)
    fetch(`http://localhost:64192/api/employees/${EmployeeID}`, {
      method: 'PUT',
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json'
      },
      body:JSON.stringify(item)
    }).then((result) => {
      result.json().then((resp) => {
        console.warn(resp)
        
        getUsers()
      })
    })
  }
  
    
        return (
            <div>
            <div className="Views">
              <h1>Update Employee Details Here </h1>
              <table>
                <thead>
                  <tr>
                    <th>Employee ID</th>
                    <th>Employee Aadhar ID</th>
                    <th>Employee Name</th>
                    <th>Designation</th>
                    <th>Speciality</th>
                    <th>Gender</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Date Of JOining</th>
                    <th>Operations</th>
                  </tr>
                  </thead>
                  <tbody>
                  {
                    users.map((item, i) =>
                      <tr key={i}>
                        <td>{item.EmployeeID}</td>
                        <td>{item.E_AadharID}</td>
                        <td>{item.EmployeeName}</td>
                        <td>{item.Designation}</td>
                        <td>{item.Speciality}</td>
                        <td>{item.Gender}</td>
                        <td>{item.Phone}</td>
                        <td>{item.Address}</td>
                        <td>{item.DOJ}</td>
                        <td><button onClick={() => selectUser(item.EmployeeID)} className='btnedit' >Edit</button></td>
        
                      </tr>
                    )
                  }
                </tbody>
              </table>
              </div>
                  <div className='editstyle'>
                     <h3>Edit Employee Details</h3>
                     <h4>After Updating Press The Button Below To Update Employee Details</h4>
                  
                  <table>
                    <tr>
                    <th>Employee ID</th>
                    <th>Employee Aadhar ID</th>
                    <th>Employee Name</th>
                    </tr>    
              <tr>
              <td><input type="number" value={EmployeeID}  onChange={(e)=>{setEmployeeId(e.target.value)}} /></td>
              <td><input type="number" value={E_AadharID}  onChange={(e)=>{setE_AadharId(e.target.value)}} /></td>
              <td><input type="text" value={EmployeeName} onChange={(e)=>{setEmployeeName(e.target.value)}} /> </td>
              </tr>
              <tr>
              <th>Designation</th>
                    <th>Speciality</th>
                    <th>Gender</th>
              </tr>
              <tr>
              <td><input type="text" value={Designation} onChange={(e)=>{setDesignation(e.target.value)}} /> </td>
              <td><input type="text" value={Speciality} onChange={(e)=>{setSpeciality(e.target.value)}} /> </td>
              <td><input type="text" value={Gender} onChange={(e)=>{setGender(e.target.value)}} /></td>
              </tr>
              <tr>
              <th>Phone</th>
                    <th>Address</th>
                    <th>Date Of Joining</th>
              </tr>
              <tr>
              <td><input type="number" value={Phone}  onChange={(e)=>{setPhone(e.target.value)}} /></td>
              <td><input type="text" value={Address}  onChange={(e)=>{setAddress(e.target.value)}} /></td>
              <td><input type="date" value={DOJ} onChange={(e)=>{setDOJ(e.target.value)}} /> </td>
              </tr>
              </table>
              <button onClick={updateUser} className='btnp' ><b>Update Details</b></button>  
</div>
</div>
          );
    
      
}
 
export default Editemployeedetails;