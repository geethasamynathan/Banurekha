import React from "react";
import './views.css';
class Viewpatients extends React.Component {

	// Constructor
	constructor(props) {
		super(props);

		this.state = {
			items: [],
			DataisLoaded: false
		};
	}

	componentDidMount() {
		fetch("http://localhost:64192/api/patients")
			.then((res) => res.json())
			.then((json) => {
				this.setState({
					items: json,
					DataisLoaded: true
				});
			})
	}
	render() {
		const { DataisLoaded, items } = this.state;
		if (!DataisLoaded) return <div>
			<h1> Pleses wait some time.... </h1> </div> ;

		return (
		
		<div className = "Views">	
			<h1> Patients Details </h1>
			
				
		<table>
			<thead>
			<tr>
			<th>Patient ID</th>
			<th>Patient Aadhar ID</th>
			<th>Patient Name</th>
			<th>Gender</th>
			<th>Date of Birth</th>
			<th>Phone</th>
			<th>Address</th>
			<th>Registered Date</th>
			</tr>
			</thead>

			<tbody>
			{
				items.map((item) => (
			<tr>
				<td> { item.PID }</td>
			<td> { item.P_AadharID }</td>
			<td> { item.PatientName }</td>
			<td> { item.Gender }</td>
			<td>{ item.DOB }</td>
			<td> { item.Phone }</td>
			<td> { item.Address }</td>
			<td> { item.RegisteredDate }</td>
			</tr>
				))
			}
			</tbody>
		</table>
		
	</div>
	);
}
}

export default Viewpatients;