import React,{useState} from 'react';
import { Grid,Paper, FormControl, TextField,Select,MenuItem,InputLabel, FormLabel,Radio,makeStyles,RadioGroup, FormControlLabel } from '@material-ui/core';
import {Button} from 'react-bootstrap';
import Axios from "axios";
const useStyle = makeStyles(theme =>({
   pageContent:{
      margin:theme.spacing(4),
      padding:theme.spacing(3)},
     
   root:{
'& .MuiFormControl-root':{
    width:'80%',
    margin:theme.spacing(3)
},

}}))

const initialfvalues ={

aadharid:'',
employeename:'',
designation:'',
speciality:'',
gender:'',
phone:'',
address:'',
doj:''
}

function Addemployee() {
   const url = "http://localhost:64192/api/employees" 
   const classes = useStyle();
    const [values,setValues]=useState(initialfvalues);
    const [errors,setErrors]=useState({});

    const handleInputChange=e =>{
        const {name,value}=e.target
        setValues({
           ...values,[name]:value
        })
    }
   
    const validate = () =>{
       let temp ={}
             temp.phone = values.phone.length>9 ? "" : "please enter valid aadhar number."
             temp.aadharid = values.aadharid.length>11  ? "" : "please enter valid aadhar number."
      
      setErrors({
         ...temp
      })
     return Object.values(temp).every(x => x== "")
    }
   
    function onSubmit(e){

      e.preventDefault();
     if(validate())
     Axios.post(url,{
       
       E_AadharID:values.aadharid,
    EmployeeName:values.employeename,
       Gender:values.gender,
       DOJ:values.doj,
       Phone:values.phone,
       Address:values.address,
       Designation:values.designation,
       Speciality:values.speciality
     })
     .then(res=>{
      console.log(res.values);
      window.alert("Employee Details Added Successfully")
     })
     
  }
 
   function onReset(){
      setValues(initialfvalues);
      setErrors({})
   }

   return ( 
      <div className='addpatientstyel'>
      <Paper className={classes.pageContent}>
         <div className='formstyle'>
            <Grid container justifyContent='center'> <h1>Add Employee Details</h1></Grid>
      <form className={classes.root}  initialfvalues={initialfvalues} autoComplete='off' onSubmit={onSubmit}>
       <Grid container>
       <Grid item xs={5} >
       <TextField  required  helperText="enter Employee AADHAR number" 
       id="outlined-number"  name='aadharid' label="Aadharid" type="number"  
       variant="outlined" value={values.aadharid}  onChange={handleInputChange}  /> 
          <TextField required helperText="enter Employee Name" id="outlined-basic" name='employeename' label="Employeename" variant="outlined" value={values.employeename} onChange={handleInputChange}/>
       <TextField required helperText="Date of Joining" id="outlined-basic" name='doj' type="date" variant='outlined' value={values.doj}  onChange={handleInputChange}/>
      </Grid>
         <Grid item xs={2}  >
            <FormControl  className='radiogender' required>
               <FormLabel>Gender</FormLabel>
               <RadioGroup row name='gender' values={values.gender} onChange={handleInputChange}>
                  <FormControlLabel value="male" control={<Radio/>} label='Male' />
                  <FormControlLabel value="female" control={<Radio/>} label='Female'/>
                  <FormControlLabel value="other" control={<Radio/>} label='Other' />
               </RadioGroup>
               </FormControl>
               
               <TextField  className='phonestyle' required   id="outlined-number" name='phone' label="Phone Number" type="number"  variant="outlined" value={values.phone}  onChange={handleInputChange}/>

         </Grid>
         
       <Grid item xs={5} >
       <TextField required helperText="enter Employee address" id="outlined-basic" name='address' label="Address" variant="outlined" value={values.address} onChange={handleInputChange}/>
       <TextField required helperText="enter Designation" id="outlined-basic" name='designation' label="Designation" variant="outlined" value={values.designation} onChange={handleInputChange}/>

      <TextField required helperText="enter Speciality" id="outlined-basic" name='speciality' label="Speciality" variant="outlined" value={values.speciality} onChange={handleInputChange}/>

       </Grid>

         <Grid container justifyContent='center' >
         <Button type='submit' variant="outline-primary" size="lg">Add Employees</Button>{' '}
         <Button onClick={onReset} type='reset' variant="outline-primary"  size="lg"  >reset</Button>{' '}      
         </Grid>
         </Grid>
         </form>
         </div>
      </Paper>
      </div>
    
    );
}

export default Addemployee;