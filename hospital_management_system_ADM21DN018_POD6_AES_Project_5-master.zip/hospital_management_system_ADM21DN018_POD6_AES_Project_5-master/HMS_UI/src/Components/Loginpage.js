import React from 'react';
import './login.css';
import { Grid, Paper, Avatar, TextField, Button } from '@material-ui/core'
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { useHistory } from "react-router-dom";
import axios from "axios";
import { useCookies } from "react-cookie";


const Login = () => {

  let history = useHistory();
  const [cookies, setCookie] = useCookies();
  console.log(cookies.login);
  if (cookies.login === "true") {

    history.push("/login/home");
  }
  function handleSubmit(e) {
    e.preventDefault();
    var email = e.target.email.value;
    var password = e.target.password.value;
    if (
      email === null ||
      email === "" ||
      password === null ||
      password === ""
    ) {
      document.getElementById("error-message").innerHTML =
        "Fields marked * are mandatory";
      return;
    }

    axios(process.env.REACT_APP_API_URL + "/api/Users", {
      method: "POST",
      data: { email: email, password: password },
    })
      .then((response) => {
        if (response.status === 200) {
          console.log(response.data);
          window.alert("Login Successful");
          setCookie("login", "true", {
            path: "/",
          });
          setCookie("user", response.data.UserId, {
            path: "/",
          });
          history.push("/login/home");
        }
      })
      .catch((error) => {
        document.getElementById("error-message").innerHTML =
          "Invalid Credentials";

        // console.log(error);
      });
  }
  const paperStyle = { padding: 20, height: '55vh', width: 300, margin: "20px auto" }
  const avatarStyle = { backgroundColor: 'blue' }
  const btnstyle = { margin: '8px 0'}

  return (
    <div className='imghome'>
      <Grid className='formalign'>
        <Paper elevation={10} style={paperStyle}>
          <Grid align='center'>
            <Avatar style={avatarStyle}><LockOutlinedIcon /></Avatar>
            <h2>Admin Login</h2>
          </Grid>
          <form onSubmit={handleSubmit}>
            <div id="error-message" className="form-text text-danger"></div>
            <div className="mb-3">
              <label htmlFor="email" className="form-label">
                Email ID *
                <input type="email" className="form" id="email" name="email" aria-describedby="emailHelp" />
              </label>
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">
                Password*
              </label>
              <input
                type="password"
                className="form"
                id="password"
                name="password"
              />
            </div>
            <button style={btnstyle} type="submit" className="btn btn-success">
              Submit
            </button>
          </form>
        </Paper>
      </Grid>
    </div>
  )
}

export default Login;