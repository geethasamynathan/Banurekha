import React,{useState} from 'react';
import { Grid,Paper, FormControl, TextField, FormLabel,Radio,makeStyles,RadioGroup, FormControlLabel } from '@material-ui/core';
import {Button} from 'react-bootstrap';
import Axios from "axios";
import './postform.css';
import ReactPaginate from 'react-paginate';
import './add.css';

const useStyle = makeStyles(theme =>({
   pageContent:{
      margin:theme.spacing(4),
      padding:theme.spacing(3)},
     
   root:{
'& .MuiFormControl-root':{
    width:'80%',
    margin:theme.spacing(3)
},

}}))

const initialfvalues ={
aadharid:'',
patientname:'',
gender:'',
dob:'',
phone:'',
address:'',
registerdate:''
}

function Addpatient() {
   const url = "http://localhost:64192/api/patients" 
   const classes = useStyle();
    const [values,setValues]=useState(initialfvalues);
    const [errors,setErrors]=useState({});

    const handleInputChange=e =>{
        const {name,value}=e.target
        setValues({
           ...values,[name]:value
        })
    }
   
    const validate = () =>{
       let temp ={}
       temp.aadharid = values.aadharid.length>11  ? "" : "please enter valid aadhar number."
       temp.phone = values.phone.length>9 ? "" : "please enter valid aadhar number."
      
      setErrors({
         ...temp
      })
     return Object.values(temp).every(x => x== "")
    }
   
    function onSubmit(e){
      e.preventDefault();
      if(validate())
     Axios.post(url,{
       P_AadharID:values.aadharid,
       PatientName:values.patientname,
       Gender:values.gender,
       DOB:values.dob,
       Phone:values.phone,
       Address:values.address,
       RegisteredDate:values.registerdate
     })
     .then(res=>{
      console.log(values);
      window.alert("Details Added Successfully")
     })
  }
 
   function onReset(){
      setValues(initialfvalues);
      setErrors({})
   }

   return ( 
      <div className='addpatientstyle'>
      <Paper className={classes.pageContent}>
         <div className='formstyle'>
            <Grid container justifyContent='center'> <h1>Add Patient Details</h1></Grid>
      <form className={classes.root}  initialfvalues={initialfvalues} autoComplete='off'
       onSubmit={onSubmit}>
       <Grid container>
       <Grid item xs={5} >
       <TextField  required  helperText="enter Patient AADHAR number" 
       id="outlined-number"  name='aadharid' label="aadharid" type="number"  
       variant="outlined" value={values.aadharid}  onChange={handleInputChange}  />   
           <TextField required helperText="enter Patient Name" id="outlined-basic" 
           name='patientname' label="Patientname" variant="outlined" 
           value={values.patientname} onChange={handleInputChange}/>
       <TextField required helperText="enter Date of Birth" id="outlined-basic" 
       name='dob' type="date" variant='outlined' value={values.dob}  
       onChange={handleInputChange}/>
      </Grid>
         <Grid item xs={2} >
            <FormControl className='radiogender' required>
               <FormLabel>Gender</FormLabel>
               <RadioGroup  name='gender' values={values.gender} onChange={handleInputChange}>
                  <FormControlLabel value="male" control={<Radio/>} label='Male' />
                  <FormControlLabel value="female" control={<Radio/>} label='Female'/>
                  <FormControlLabel value="other" control={<Radio/>} label='Other' />
               </RadioGroup>
               </FormControl>
              
         </Grid>
         
       <Grid item xs={5} >
       <TextField required helperText="enter Patient address" 
       id="outlined-basic" name='address' label="Address" variant="outlined" 
       value={values.address} onChange={handleInputChange}/>
              <TextField  required  helperText="enter Patient 
              Phone Number" id="outlined-number" name='phone' label="Phone Number"
               type="number"  variant="outlined" value={values.phone}  
               onChange={handleInputChange}/>
               <TextField required helperText="Register date" 
               id="outlined-basic" name='registerdate' type="date"
                variant='outlined' value={values.registerdate} 
                onChange={handleInputChange}/>
       </Grid>

         <Grid container justifyContent='center' >
         <Button type='submit' variant="outline-primary"  size="lg">Add Patient</Button>{' '}
         <Button onClick={onReset} type='reset' variant="outline-primary" className='btng' size="lg">reset</Button>{' '}      
         </Grid>
         </Grid>
         </form>
         </div>
      </Paper>
      </div>
    
    );

}

export default Addpatient;