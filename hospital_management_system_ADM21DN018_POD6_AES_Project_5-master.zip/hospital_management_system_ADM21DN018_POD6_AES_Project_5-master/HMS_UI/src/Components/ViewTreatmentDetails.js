import React from "react";
import './views.css';
class ViewTreatmentDetails extends React.Component {

	// Constructor
	constructor(props) {
		super(props);

		this.state = {
			items: [],
			DataisLoaded: false
		};
	}

	// ComponentDidMount is used to
	// execute the code
	componentDidMount() {
		fetch("http://localhost:64192/api/treatmentdetails")
			.then((res) => res.json())
			.then((json) => {
				this.setState({
					items: json,
					DataisLoaded: true
				});
			})
	}
	render() {
		const { DataisLoaded, items } = this.state;
		if (!DataisLoaded) return <div>
			<h1> Pleses wait some time.... </h1> </div> ;

		return (
		
		<div className = "Views">	
			<h1> Treatment Details </h1>
			
				
		<table>
			<thead>
			<tr>
            <th>Treatment ID</th>
			<th>Patient ID</th>
			<th>Aadhar ID</th>
			<th>Symptoms</th>
			<th>Diagnosis</th>
			<th>Fees</th>
            <th>Employee ID</th>
			<th>Visited Date</th>
			</tr>
			</thead>

			<tbody>
			{
				items.map((item) => (
			<tr>
                <td> { item.TreatmentID }</td>
				<td> { item.PID }</td>
                <td> { item.P_AadharID }</td>
			<td> { item.Symptoms }</td>
			<td> { item.Diagnosis }</td>
			<td>{ item.Fees }</td>
			<td> { item.EmployeeID }</td>
			<td> { item.VisitedDate }</td>
			</tr>
				))
			}
			</tbody>
		</table>
		
	</div>
	);
}
}

export default ViewTreatmentDetails;