import React, { Component } from 'react';
import './EditPage.css';
import { useEffect, useState } from 'react'
function EditPatientdetails() {
    const [users, setUser] = useState([]);
    const [PID, setPid] = useState('');
    const [P_AadharID, setP_AadharId] = useState("");
    const [PatientName, setPatientName] = useState("");
    const [Phone, setPhone] = useState("");
    const [Address, setAddress]= useState("");
    const [Gender, setGender] = useState("");
    const [DOB, setDOB] = useState("");
    const [RegisteredDate, setRegisteredDate]= useState("");

  useEffect(() => {
    getUsers();
  }, [])

  function getUsers() {
    fetch("http://localhost:64192/api/patients").then((result) => {
      result.json().then((resp) => {
        // console.warn(resp)
        setUser(resp)
        setPid(resp[0].PID)
        setP_AadharId(resp[0].P_AadharID)
        setPatientName(resp[0].PatientName)
        setGender(resp[0].Gender)
        setDOB(resp[0].DOB)
        setPhone(resp[0].Phone)
        setAddress(resp[0].Address)
        setRegisteredDate(resp[0].RegisteredDate)

      })
    })
  }

  function selectUser(PID)
  {
    let item=users[PID-1];
  
        setPid(item.PID)
        setP_AadharId(item.P_AadharID)
        setPatientName(item.PatientName)
        setGender(item.Gender)
        setDOB(item.DOB)
        setPhone(item.Phone)
        setAddress(item.Address)
        setRegisteredDate(item.RegisteredDate)
  }
  
  
  function updateUser()
  {
    let item={PID,P_AadharID,PatientName,Gender,DOB,Phone,Address,RegisteredDate}
    console.warn("item",item)
    fetch(`http://localhost:64192/api/patients/${PID}`, {
      method: 'PUT',
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json'
      },
      body:JSON.stringify(item)
    }).then((result) => {
      result.json().then((resp) => {
        console.warn(resp)
        getUsers()
      })
    })
  }
    
        return (
          <div>
            <div className="Views">
              <h1>Update Patient Data</h1>
              <table>
                <thead>
                  <tr>
                    <td>Patient ID</td>
                    <td>Patient Aadhar ID</td>
                    <td>Patient Name</td>
                    <td>Gender</td>
                    <td>DOB</td>
                    <td>Phone</td>
                    <td>Address</td>
                    <td>RegisteredDate</td>
                    <td>Operations</td>
                  </tr>
                  </thead>
                  <tbody>
                  {
                    users.map((item, i) =>
                      <tr key={i}>
                        <td>{item.PID}</td>
                        <td>{item.P_AadharID}</td>
                        <td>{item.PatientName}</td>
                        <td>{item.Gender}</td>
                        <td>{item.DOB}</td>
                        <td>{item.Phone}</td>
                        <td>{item.Address}</td>
                        <td>{item.RegisteredDate}</td>
                        <td><button onClick={() => selectUser(item.PID)} className='btnedit' >Edit</button></td>
                      </tr>
                    )
                  }
                </tbody>
              </table>
              </div>
              <div className='editstyle'>
              <h3>Edit Patient Details</h3>
                     <h4><b>After Finish Editing Details Press The Button Below To Update The Details</b></h4>
                  
                <table>
                <tr>
                    <th>Patient ID</th>
                    <th>Patient Aadhar ID</th>
                    <th>Patient Name</th>
                    <th>Gender</th>
                </tr>
                <tr>
              <td><input type="number" value={PID}  onChange={(e)=>{setPid(e.target.value)}} /></td>
              <td><input type="number" value={P_AadharID}  onChange={(e)=>{setP_AadharId(e.target.value)}} /></td>
              <td><input type="text" value={PatientName} onChange={(e)=>{setPatientName(e.target.value)}} /></td>
              <td><input type="text" value={Gender} onChange={(e)=>{setGender(e.target.value)}} /> </td>
                 </tr>
                 <tr>
                 <th>DOB</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>RegisteredDate</th>
                  
                 </tr>
                 <tr>
              <td><input type="date" value={DOB} onChange={(e)=>{setDOB(e.target.value)}} /></td>
              <td><input type="number" value={Phone}  onChange={(e)=>{setPhone(e.target.value)}} /> </td>
              <td><input type="text" value={Address}  onChange={(e)=>{setAddress(e.target.value)}} /> </td>
              <td><input type="date" value={RegisteredDate} onChange={(e)=>{setRegisteredDate(e.target.value)}} /> </td>
                </tr>
              </table>
                <button onClick={updateUser} className='btnp' ><b>Update Details</b></button>  
              </div>
            </div>
          );
    
      
}
 
export default EditPatientdetails;