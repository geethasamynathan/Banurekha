import React,{useState} from 'react';
import { Grid,Paper,TextField,makeStyles} from '@material-ui/core';
import {Button} from 'react-bootstrap';
import Axios from "axios";
const useStyle = makeStyles(theme =>({
   pageContent:{
      margin:theme.spacing(4),
      padding:theme.spacing(3)},
      root:{
'& .MuiFormControl-root':{
    width:'80%',
    margin:theme.spacing(1)
},

}}))

const initialfvalues ={
   pid: '',
aadharid:'',
symptoms:'',
diagnosis:'',
fees:'',
employeeid:'',
visiteddate:''
}

function AddTreatmentdetails() {
   const url = "http://localhost:64192/api/treatmentdetails" 
   const classes = useStyle();
    const [values,setValues]=useState(initialfvalues);
    const [errors,setErrors]=useState({});

    const handleInputChange=e =>{
        const {name,value}=e.target
        setValues({
           ...values,[name]:value
        })
    }
   
    const validate = () =>{
       let temp ={}
       temp.aadharid = values.aadharid.length>11 ? "" : "please enter valid aadhar number."
      
      setErrors({
         ...temp
      })
     return Object.values(temp).every(x => x== "")
    }
   
    function onSubmit(e){
      e.preventDefault();
    
      if(validate())
    Axios.post(url,{       
       PID: values.pid,
       P_AadharID:values.aadharid,
       symptoms:values.symptoms,
       diagnosis:values.diagnosis,
       fees:values.fees,
       employeeid:values.employeeid,
       visiteddate:values.visiteddate
     })
     .then(res=>{
      console.log(res.values);
      window.alert("Treatment Details Added Successfully")
     })
  }
 
   function onReset(){
      setValues(initialfvalues);
      setErrors({})
   }

   return ( 
      <div className='patientdetailstyle'>
      <Paper className={classes.pageContent}>
         <div className='patientformstyle'>
         <Grid container justifyContent='center'> <h1>Add Treatment Details</h1></Grid>
      <form className={classes.root}  initialfvalues={initialfvalues} autoComplete='off' onSubmit={onSubmit}>
       <Grid container>
       <Grid item xs={6} >
       <TextField  required  helperText="enter Patient id" id="outlined-number" name='pid' label="Patient id" type="number"  variant="outlined" value={values.pid}  onChange={handleInputChange}  />
       <TextField  required   helperText="aadharid" id="outlined-number" name='aadharid' label="aadharid" type="number"  variant="outlined" value={values.aadharid}  onChange={handleInputChange}  />    
          <TextField required helperText="symptoms" id="outlined-basic" name='symptoms' label="Symptoms" variant="outlined" value={values.symptoms} onChange={handleInputChange}/>
       <TextField required helperText="Visited Date" id="outlined-basic" name='visiteddate' type="date" variant='outlined' value={values.visiteddate}  onChange={handleInputChange}/>
      </Grid>
         
           
       <Grid item xs={6}>
      <TextField   required   id="outlined-basic" name='diagnosis' label="Diagnosis"  variant="outlined" value={values.diagnosis}  onChange={handleInputChange}/>
      <TextField required helperText="Fees" id="outlined-basic" name='fees' label="Fees" variant="outlined" value={values.fees} onChange={handleInputChange}/>
      <TextField required helperText="Employeeid" id="outlined-basic" name='employeeid' label="Employeeid" variant="outlined" value={values.employeeid} onChange={handleInputChange}/>

       </Grid>

         <Grid container  justifyContent='center'>
         <Button type='submit' className='addemployeebtn' variant="outline-primary"  size="lg">Add Details</Button>{' '}
         <Button onClick={onReset} className='employeeresetbtn' type='reset' variant="outline-primary"  size="lg">reset</Button>{' '}      
         </Grid>
         </Grid>
         </form>
         </div>
      </Paper>
      </div>
    
    );
}

export default AddTreatmentdetails;