import React from "react";
import './views.css';
class Viewemployee extends React.Component {

	// Constructor
	constructor(props) {
		super(props);

		this.state = {
			items: [],
			DataisLoaded: false
		};
	}

	// ComponentDidMount is used to
	// execute the code
	componentDidMount() {
		fetch("http://localhost:64192/api/employees")
			.then((res) => res.json())
			.then((json) => {
				this.setState({
					items: json,
					DataisLoaded: true
				});
			})
	}
	render() {
		const { DataisLoaded, items } = this.state;
		if (!DataisLoaded) return <div>
			<h1> Pleses wait some time.... </h1> </div> ;

		return (
		
		<div className = "Views">	
		<h1> Employees Details </h1>	
	<table>
		<thead>
		<tr>
		<th>EmployeeID</th>
		<th>Employee Aadhar ID</th>
		<th>EmployeeName</th>
		<th>Designation</th>
		<th>Speciality</th>
		<th>Gender</th>
		<th>Phone</th>
		<th>Address</th>
		<th>Date Of Joining</th>
		</tr>
		</thead>

		<tbody>
		{
			items.map((item) => (
		<tr><td> { item.EmployeeID }</td>
		<td> { item.E_AadharID }</td>
		<td> { item.EmployeeName }</td>
		<td>{ item.Designation }</td>
		<td> { item.Speciality }</td>
		<td> { item.Gender }</td>
		<td> { item.Phone }</td>
		<td> { item.Address }</td>
		<td> { item.DOJ }</td>
		</tr>
			))
		}
		</tbody>
	</table>
	
</div>
	);
}
}

export default Viewemployee;