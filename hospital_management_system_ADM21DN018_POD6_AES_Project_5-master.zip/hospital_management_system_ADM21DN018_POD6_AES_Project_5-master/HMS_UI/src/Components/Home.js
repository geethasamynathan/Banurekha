import React from 'react';
import './Home.css';

const Home = () =>{
        return (
        <div className='bgimg'>
                <div className='homecontent'>
                        <h1><strong className='brand-name'>Welcome to Hospital Management System</strong></h1>
                        <h2 className='my-3'>This is the home page of our application.</h2>
                        <div className='mt-3'>
                                <h3>Let's Get Started</h3>
                        </div>
                        <div className='mt-3'>
                            
                            <p><strong>USE DROPDOWN BUTTONS FROM TOP NAVBAR TO NAVIGATE TO
                                     DIFFERENT PAGES. </strong></p>
                        <p><strong>TO ADD NEW EMPLOYEES, SEE EXISTING EMPLOYEES OR UPDATE DETAILS
                                 USE THE EMPLOYEES DROPDOWN BUTTON.</strong></p>
                        <p><strong>TO REGISTER PATIENTS, SEE EXISTING PATIENTS OR UPDATE DETAILS
                                 USE THE PATIENTS DROPDOWN BUTTON.</strong></p>
                                    
                        </div>
                        </div>
                    </div>    
        );
}

export default Home;
