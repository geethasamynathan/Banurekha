import React from 'react';
import {Nav,NavDropdown,Navbar,Container} from 'react-bootstrap';
import { useCookies } from "react-cookie";
import { useHistory } from "react-router-dom";
import { NavLink, Switch, Route } from "react-router-dom";


function Newnav () {
    const [cookies, setCookie, removeCookie] = useCookies();
  let history = useHistory();

    function logoutHandle() {
        removeCookie("login", { path: "/" });
        removeCookie("user", { path: "/" });
        console.log("logout");
        history.push("/");
      }
    return (
<Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
  <Container>
  <Navbar.Brand href="#home" >HOSPITAL MANAGEMENT SYSTEM</Navbar.Brand>
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
    <Switch>
        <Route path="/login">
  <Navbar.Collapse className="justify-content-end">
      <Nav>
    <Nav.Link eventKey={2} href="/login/home">
        Home
      </Nav.Link>
    <NavDropdown title="Employees" id="collasible-nav-dropdown">
        <NavDropdown.Item href="/login/addemployee">Add Employees </NavDropdown.Item>
        <NavDropdown.Item href="/login/viewemployee">View Employees</NavDropdown.Item>
        <NavDropdown.Item href="/login/updateemployee">Update Employees</NavDropdown.Item>
    </NavDropdown>
      <NavDropdown title="Patients" id="collasible-nav-dropdown">
        <NavDropdown.Item href="/login/addpatients">Add New Patients</NavDropdown.Item>
        <NavDropdown.Item href="/login/viewpatients">View Patients</NavDropdown.Item>
        <NavDropdown.Item href="/login/updatepatients">Update Details</NavDropdown.Item>
        <NavDropdown.Item href="/login/addtreatmentdetails">Add Treatment Details</NavDropdown.Item>
        <NavDropdown.Item href="/login/viewtreatment">View Treatment Details</NavDropdown.Item>
        
    </NavDropdown>
      <Nav.Link  onClick={logoutHandle} href="#">
       Logout
      </Nav.Link>
    </Nav>
  </Navbar.Collapse>
       </Route>
    </Switch>
  </Container>
</Navbar>
    );
};
export default Newnav;