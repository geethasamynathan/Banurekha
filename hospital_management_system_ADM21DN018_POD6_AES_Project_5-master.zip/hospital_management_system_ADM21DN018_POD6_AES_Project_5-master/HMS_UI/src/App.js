import React from 'react';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import {Switch,Route, Redirect} from 'react-router-dom';
import Home from './Components/Home';
import { BrowserRouter } from 'react-router-dom/cjs/react-router-dom.min';
import Newnav from './Components/Newnav';
import Viewemployee from './Components/Viewemployee';
import Viewpatients from './Components/Viewpatients';
import Loginpage from './Components/Loginpage';
import ViewTreatmentDetails from './Components/ViewTreatmentDetails';
import Addpatient from './Components/Addpatient';
import Addemployee from './Components/Addemployee';
import AddTreatmentdetails from './Components/AddTreatmentdetails';
import EditPatientdetails from './Components/EditPatientdetails';
import Editemployeedetails from './Components/Editemployeedetails';

const App =()=> {
  return (
      <>
      <BrowserRouter>
      <Newnav/>
      <Switch>
      <Route exact path="/" component={Loginpage}/>
         <Route path="/login/home" component={Home}/>
         <Route path="/login/addemployee" component={Addemployee}/>
         <Route path="/login/viewemployee" component={Viewemployee}/>
         <Route path="/login/updateemployee" component={Editemployeedetails}/>
         <Route path="/login/viewpatients" component={Viewpatients}/>
         <Route path="/login/updatepatients" component={EditPatientdetails}/>
         <Route path="/login/addtreatmentdetails" component={AddTreatmentdetails}/>
         <Route path="/login/viewtreatment" component={ViewTreatmentDetails}/>
         <Route path="/login/addpatients" component={Addpatient}/>
         <Redirect to="/" />
      </Switch>
      </BrowserRouter>
      </>
  );

  };
export default App;

