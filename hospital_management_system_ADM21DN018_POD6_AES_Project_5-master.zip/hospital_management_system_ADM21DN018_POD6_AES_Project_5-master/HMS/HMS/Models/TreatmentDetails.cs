﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace HMS.Models
{
    [Table("Treatments")]
    public class TreatmentDetails
    {

        [Key]
        public long TreatmentID { get; set; }

        [ForeignKey("ID")]
        public int PID { get; set; }
        public virtual Patient ID { get; set; }

        [Required]
        public long P_AadharID { get; set; }

        [Required, StringLength(100)]
        public string Symptoms { get; set; }

        [Required, StringLength(100)]
        public string Diagnosis { get; set; }

        [Required]
        public long Fees { get; set; }

        [ForeignKey("EID")]
        public int EmployeeID { get; set; }
        public virtual Employee EID { get; set; }

        [Required]
        public DateTime VisitedDate { get; set; }


    }
}