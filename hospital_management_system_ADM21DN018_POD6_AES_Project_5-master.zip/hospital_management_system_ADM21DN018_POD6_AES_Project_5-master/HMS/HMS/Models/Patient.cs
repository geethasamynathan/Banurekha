﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HMS.Models
{
    [Table("Patients")]
    public class Patient
    {
        [Key]
        public int PID { get; set; }

        [Required]
        public long P_AadharID { get; set; }

        [Required, StringLength(50)]
        public string PatientName { get; set; }

        [Required, StringLength(10)]
        public string Gender { get; set; }

        [Required]
        public DateTime DOB { get; set; }

        [Required]
        public long Phone { get; set; }

        [Required, StringLength(50)]
        public string Address { get; set; }

        [Required]
        public DateTime RegisteredDate { get; set; }


    }
}