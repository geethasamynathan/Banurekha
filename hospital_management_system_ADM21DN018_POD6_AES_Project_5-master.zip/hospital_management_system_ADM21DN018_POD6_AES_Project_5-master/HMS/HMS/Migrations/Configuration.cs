﻿namespace HMS.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using HMS.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<HMS.Data.HMSContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(HMS.Data.HMSContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.
            context.Patients.AddOrUpdate(x => x.PID,
                new Patient()
                {
                    PID=1,
                    P_AadharID = 1223334,
                    PatientName = "Karthik",
                    Gender = "Male",
                    DOB = new DateTime(1999, 01, 01),
                    Phone = 9988776655,
                    Address = "Hassan",
                    RegisteredDate = new DateTime(2022, 02, 03)
                },
                new Patient()
                {
                    PID = 2,
                    P_AadharID = 223334444,
                    PatientName = "Sonali",
                    Gender = "Female",
                    DOB = new DateTime(1998, 07, 04),
                    Phone = 9548457665,
                    Address = "North India",
                    RegisteredDate = new DateTime(2022, 02, 03)
                }
                );

            context.Employees.AddOrUpdate(x => x.EmployeeID,
                 new Employee()
                 {
                     
                     EmployeeID = 12345,
                     E_AadharID = 1223334444,
                     EmployeeName = "Sirisha",
                     Designation = "Doctor",
                     Speciality = "Dental",
                     Gender = "female",
                     Phone = 9934576655,
                     Address = "ballari",
                     DOJ = new DateTime(2018, 02, 03)
                 },
                 new Employee()
                 {
                     
                     EmployeeID = 45678,
                     E_AadharID = 2233344445,
                     EmployeeName = "Gourab",
                     Designation = "Doctor",
                     Speciality = "Cardiologist",
                     Gender = "Male",
                     Phone = 9934579055,
                     Address = "Kolkata",
                     DOJ = new DateTime(2016, 02, 03)
                 }
                 );

            context.Users.AddOrUpdate(x => x.UserID,
                new User()
                {
                    UserID = "new",
                    Email = "User1@gmail.com",
                    Password = "User@01",

                },
               new User()
               {
                   UserID = "old",
                   Email = "User2@gmail.com",
                   Password = "User@02",

               }
                );
        }
    }
}
