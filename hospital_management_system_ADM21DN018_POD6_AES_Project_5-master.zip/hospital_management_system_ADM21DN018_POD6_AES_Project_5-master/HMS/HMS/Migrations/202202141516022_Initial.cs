﻿namespace HMS.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        EmployeeID = c.Int(nullable: false, identity: true),
                        E_AadharID = c.Long(nullable: false),
                        EmployeeName = c.String(nullable: false, maxLength: 50),
                        Designation = c.String(nullable: false, maxLength: 20),
                        Speciality = c.String(nullable: false, maxLength: 20),
                        Gender = c.String(nullable: false, maxLength: 10),
                        Phone = c.Long(nullable: false),
                        Address = c.String(nullable: false, maxLength: 50),
                        DOJ = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.EmployeeID);
            
            CreateTable(
                "dbo.Patients",
                c => new
                    {
                        PID = c.Int(nullable: false, identity: true),
                        P_AadharID = c.Long(nullable: false),
                        PatientName = c.String(nullable: false, maxLength: 50),
                        Gender = c.String(nullable: false, maxLength: 10),
                        DOB = c.DateTime(nullable: false),
                        Phone = c.Long(nullable: false),
                        Address = c.String(nullable: false, maxLength: 50),
                        RegisteredDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.PID);
            
            CreateTable(
                "dbo.Treatments",
                c => new
                    {
                        TreatmentID = c.Long(nullable: false, identity: true),
                        PID = c.Int(nullable: false),
                        P_AadharID = c.Long(nullable: false),
                        Symptoms = c.String(nullable: false, maxLength: 100),
                        Diagnosis = c.String(nullable: false, maxLength: 100),
                        Fees = c.Long(nullable: false),
                        EmployeeID = c.Int(nullable: false),
                        VisitedDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.TreatmentID)
                .ForeignKey("dbo.Employees", t => t.EmployeeID, cascadeDelete: true)
                .ForeignKey("dbo.Patients", t => t.PID, cascadeDelete: true)
                .Index(t => t.PID)
                .Index(t => t.EmployeeID);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        UserID = c.String(nullable: false, maxLength: 128),
                        Email = c.String(nullable: false, maxLength: 50),
                        Password = c.String(nullable: false, maxLength: 50),
                    })
                .PrimaryKey(t => t.UserID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Treatments", "PID", "dbo.Patients");
            DropForeignKey("dbo.Treatments", "EmployeeID", "dbo.Employees");
            DropIndex("dbo.Treatments", new[] { "EmployeeID" });
            DropIndex("dbo.Treatments", new[] { "PID" });
            DropTable("dbo.Users");
            DropTable("dbo.Treatments");
            DropTable("dbo.Patients");
            DropTable("dbo.Employees");
        }
    }
}
