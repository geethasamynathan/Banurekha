﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using HMS.Data;
using HMS.Models;
using System.Web.Http.Cors;

namespace HMS.Controllers
{
    [EnableCors("*", "*", "POST")]
    public class TreatmentDetailsController : ApiController
    {
        private HMSContext db = new HMSContext();

        // GET: api/TreatmentDetails
        public IQueryable<TreatmentDetails> GetTreatmentDetails()
        {
            return db.TreatmentDetails;
        }

        // GET: api/TreatmentDetails/5
        [ResponseType(typeof(TreatmentDetails))]
        public IHttpActionResult GetTreatmentDetails(long id)
        {
            TreatmentDetails treatmentDetails = db.TreatmentDetails.Find(id);
            if (treatmentDetails == null)
            {
                return NotFound();
            }

            return Ok(treatmentDetails);
        }

        // PUT: api/TreatmentDetails/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTreatmentDetails(long id, TreatmentDetails treatmentDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != treatmentDetails.TreatmentID)
            {
                return BadRequest();
            }

            db.Entry(treatmentDetails).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TreatmentDetailsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/TreatmentDetails
        [ResponseType(typeof(TreatmentDetails))]
        public IHttpActionResult PostTreatmentDetails(TreatmentDetails treatmentDetails)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.TreatmentDetails.Add(treatmentDetails);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = treatmentDetails.TreatmentID }, treatmentDetails);
        }

        // DELETE: api/TreatmentDetails/5
        [ResponseType(typeof(TreatmentDetails))]
        public IHttpActionResult DeleteTreatmentDetails(long id)
        {
            TreatmentDetails treatmentDetails = db.TreatmentDetails.Find(id);
            if (treatmentDetails == null)
            {
                return NotFound();
            }

            db.TreatmentDetails.Remove(treatmentDetails);
            db.SaveChanges();

            return Ok(treatmentDetails);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TreatmentDetailsExists(long id)
        {
            return db.TreatmentDetails.Count(e => e.TreatmentID == id) > 0;
        }
    }
}